function say() {
  alert("Ayo Semangat Pratikum");

}
